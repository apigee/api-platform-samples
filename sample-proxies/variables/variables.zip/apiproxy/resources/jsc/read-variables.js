 var a = context.getVariable("mock.city");
print(a);

var b = context.getVariable("mock.state");
print(b);

var c = context.getVariable("mock.firstName");
print(c);

var d = context.getVariable("mock.lastName");
print(d);